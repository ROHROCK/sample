# Ansible Collection - rohit.sample

Documentation for the collection.
# sample
